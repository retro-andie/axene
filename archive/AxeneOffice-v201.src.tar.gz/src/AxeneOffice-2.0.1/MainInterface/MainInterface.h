/*
** MainInterface.h for AxeneOffice in MainInterface/
**
** Copyright (C) 1995-2000 Axene.
** Authors: St�phane Boisson, Antoine Buat, Robin Castanier and Emmanuel Paris.
** Email: xcalibur@axene.org
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    (at your option) any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Started on  Mon Jul 17 19:23:23 1995 Antoine Buat
** Last update Thu May 22 16:39:05 1997 Robin Castanier
*/

#ifndef _MainInterface_h
#define _MainInterface_h

#include "xcalibur.h"
#include "ManageWidget.h" 

#include <X11/Intrinsic.h>
#include <Xm/Form.h>

/* define the method for Class MainInterface */
typedef struct
{
  F_STD;
  void (*create_TopLevel)();
  void (*map_TopLevel)();
  void (*unmap_TopLevel)();
  void (*attach_top)();
  void (*attach_bottom)();
  void (*attach_left)();
  void (*attach_right)();
  void (*set_main_icon)();
  void (*reopen_display)();
} sf_MainInterface;

/* define the MainInterface Class */
typedef struct
{
 sf_MainInterface	*f;
 Widget			w_This;
 Widget			w_Main;
 Widget			w_Hidden;
 char			*display_name;
} c_MainInterface;

extern sf_MainInterface fc_MainInterface;

#endif





