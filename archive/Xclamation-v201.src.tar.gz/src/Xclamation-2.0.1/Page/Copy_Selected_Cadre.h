/*
** Copy_Selected_Cadre.h for Xclamation in Page/
**
** Copyright (C) 1994-2000 Axene.
** Authors: St�phane Boisson, Antoine Buat, Robin Castanier and Emmanuel Paris.
** Email: xcalibur@axene.org
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    (at your option) any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Started on  Mon Jul 17 20:27:13 1995 Emmanuel Paris
** Last update Mon Jul 17 20:27:13 1995 Emmanuel Paris
*/


#ifndef _Copy_Selected_Cadre_h
#define _Copy_Selected_Cadre_h

extern void copy_selected_cadre_init();
extern void copy_selected_cadre_abort();
extern void copy_selected_cadre_done();
extern void copy_selected_cadre_to_xy();
extern void copy_selected_cadre_trace();
extern void copy_selected_cadre_drag();

#endif
