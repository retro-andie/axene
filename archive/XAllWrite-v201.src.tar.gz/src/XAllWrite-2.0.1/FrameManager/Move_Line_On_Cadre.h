/*
** Move_Line_On_Cadre.h for XAllWrite in FrameManager/
**
** Copyright (C) 1995-2000 Axene.
** Authors: St�phane Boisson, Antoine Buat, Robin Castanier and Emmanuel Paris.
** Email: xcalibur@axene.org
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    (at your option) any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Started on  Mon Jul 17 20:01:01 1995 Emmanuel Paris
** Last update Thu Apr 23 16:16:13 1998 Emmanuel Paris
*/

#ifndef _Move_Line_On_Cadre_h
#define _Move_Line_On_Cadre_h

extern void move_line_on_cadre_init();
extern void move_line_on_cadre_abort();
extern void move_line_on_cadre_done();
extern void move_line_on_cadre_to_xy();
extern void move_line_on_cadre_trace();

#endif

