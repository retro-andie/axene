/*
** version.h  - generated header for version info
** Copyright (c) 1994-1996. All Rights reserved.
** Xcalibur Team (S.Boisson, A.Buat, R.Castanier, E.Paris)
** EMail: <xcalibur@axene.org>
**
*/
 
#ifndef _version_h_
#define _version_h_

#define MAJOR 2
#define MINOR 0
#define PL 1
#define DATE "Fri Oct 2 15:26:47 MET DST 1998"

#endif
