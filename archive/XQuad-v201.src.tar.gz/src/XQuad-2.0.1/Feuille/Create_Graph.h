/*
** Create_Graph.h for XQuad in Feuille/
** define Create Graph function
**
** Copyright (C) 1995-2000 Axene.
** Authors: St�phane Boisson, Antoine Buat, Robin Castanier and Emmanuel Paris.
** Email: xcalibur@axene.org
**
**    This program is free software; you can redistribute it and/or modify
**    it under the terms of the GNU General Public License as published by
**    the Free Software Foundation; either version 2 of the License, or
**    (at your option) any later version.
**
**    This program is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**    GNU General Public License for more details.
**
**    You should have received a copy of the GNU General Public License
**    along with this program; if not, write to the Free Software
**    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
** Started on  Tue Mar 28 13:43:16 1995 Emmanuel Paris
** Last update Thu May 25 18:29:27 1995 St�phane Boisson
*/

#ifndef _Create_Graphs_h
#define _Create_Graphs_h

#include "FrameManagerStd.h"
#include "Feuille.h"

#define CG_CREATE_FRAME 0
#define CG_CHOOSE_PARAM 1

typedef struct 
{
  int function_type;
  int step;
} 
d_Create_Graph;

#endif
